if (!window.Promise) {
  window.Promise = require('promise-polyfill');
}

Object.assign = require('object-assign');
