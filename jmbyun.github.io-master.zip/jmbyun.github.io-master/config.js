window.__PAW_CONFIG__ = {
    googleApiKey: 'AIzaSyBoX_m8IQZO2Fq__4XgkIRADhVXTJwtsbs',
    googleSheetDocId: '1AKmXQRHbW2Cu0VpVzM5wewL5W8HtQRgTwhdAugdqJJU',
}